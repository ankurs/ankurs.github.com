<?php
ob_start();
/*
Here is the Database -->
CREATE TABLE IF NOT EXISTS `url` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(300) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;
*/
$host="localhost";
$dbuser="user";
$dbpass="password";
$db="database";
$con = mysql_connect($host,$dbuser,$dbpass);
mysql_select_db($db,$con);
if (isset($_GET['url']))
{
	$query="select * from url where id ='".base_convert(mysql_real_escape_string($_GET['url']),36,10)."'";
	$res = mysql_query($query,$con);
	$row=mysql_fetch_row($res);
	header("Location: ".$row[1]);
}
ob_end_flush();
?>