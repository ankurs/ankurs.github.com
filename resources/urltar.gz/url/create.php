<html>
<head>
<title>Url Shortner</title>
</head>
<body>
<?php
ob_start();
$host="localhost";
$dbuser="user";
$dbpass="password";
$db="database";
$con = mysql_connect($host,$dbuser,$dbpass);
mysql_select_db("url",$con);
if (!isset($_POST['shorten']))
{
	echo "<center><h3>Enter the url to shorten</h3><form method='POST'><input type='text' name='url' />
		<input type='submit' name='shorten' value='Shorten' /></form></center>";
}
else
{
	if (isset($_POST['url']))
	{
		$url=" ".mysql_real_escape_string($_POST['url']);
		if (strpos($url,"http://") or strpos($url,"https://") or strpos($url,"ftp://"))
		{
			$url=mysql_real_escape_string($_POST['url']);
		}
		else
		{
			$url="http://".mysql_real_escape_string($_POST['url']);
		}
		$q="select * from url where url='{$url}'";
		$res = mysql_query($q,$con);
		$row=mysql_fetch_row($res);
		if (!$row)
		{
			$query="insert into url set url='{$url}'";
			$res = mysql_query($query,$con);
		}
		$query1="select id from url where url='{$url}' limit 1";
		$res=mysql_query($query1,$con);
		$row=mysql_fetch_row($res);
		echo "shortened url is http://yoursite.com/".base_convert($row[0],10,36);
	}
}
ob_end_flush();
?>
</body>
</html>