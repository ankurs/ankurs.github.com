This is a Windows Vista Executable for I-ON Auto Login Script

run this my going to this folder in command line ( cmd ) and type ialv1.exe
To change the username and password delete the ial.info file

for further information contact - Ankur
http://ankurs.com
